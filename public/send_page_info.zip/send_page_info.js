  function doProc() {
    var formdata = new FormData();

    // description = document.getElementsByClassName('VideoDescription-html')[0].outerHTML
    // if(document.getElementsByClassName('VideoOwnerInfo-pageLink')[0]) {
    //   description = description + document.getElementsByClassName('VideoOwnerInfo-pageLink')[0].outerHTML
    // }
    // if(document.getElementsByClassName('ChannelInfo-pageLinks')[0]) {
    //   description = description + document.getElementsByClassName('ChannelInfo-pageLinks')[0].outerHTML
    // }

    // formdata.append("dance[url]", document.URL);
    // formdata.append("dance[title]", document.getElementsByClassName('VideoTitle')[0].textContent);
    // formdata.append("dance[description]", description );

    formdata.append("article[url]", document.URL);
    formdata.append("article[body]", document.body.outerHTML);

    fetch(
      "https://192.168.2.180:3002/api/articles",
      {
        method: 'POST',
        body: formdata
      }
    ).then((response) => {
      if(response.ok){
        console.log("success")
      }else{
        console.log("failure")
      }
    })

  }
  
  // if (document.readyState === 'loading') {  // Loading hasn't finished yet
  //   document.addEventListener('DOMContentLoaded', doProc);
  // } else {  // `DOMContentLoaded` has already fired
  //   doProc();
  // }

  browser.runtime.onMessage.addListener((message) => {
    doProc();
  });

  // // 変更を監視するノードを選択
  // const targetNode = document.getElementsByTagName('body')[0];

  // // (変更を監視する) オブザーバーのオプション
  // const config = { attributes: true, childList: false, subtree: false };

  // // 変更が発見されたときに実行されるコールバック関数
  // const callback = function(mutationsList, observer) {
  //   // Use traditional 'for loops' for IE 11
  //   for(const mutation of mutationsList) {
  //     if(!mutation.target.className.includes('is-page-changing')) { doProc(); }
  //   }
  // };

  // // コールバック関数に結びつけられたオブザーバーのインスタンスを生成
  // const observer = new MutationObserver(callback);

  // // 対象ノードの設定された変更の監視を開始
  // observer.observe(targetNode, config);